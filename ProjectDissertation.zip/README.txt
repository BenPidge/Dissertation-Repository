Run the main.py file to launch the system.
Usage of the Dev Menu is not recommended as it is not designed for non-expert users, but it 
can be safely used if you force-shut the system before completing an insertion.

The main packages required are: PyQt5, Altair, Pymoo.